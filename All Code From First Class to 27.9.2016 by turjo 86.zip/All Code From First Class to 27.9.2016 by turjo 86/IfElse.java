
public class IfElse 
{
    
    public static void main(String[] args)
    {
        int number = 20;
        if(number<30)
        {
            System.out.println("Number Is  Less Than 30");
        }
        else{
            System.out.println("The Number Is Greater Than 30");
        }
    }
    
}
