
public class Programmer {
    
    public static void display()
    {
        System.out.println("I am A Programmer");
    }
    
}
