
public class TesttoString
{
    public static void main(String[] args)
    {
        //Testto string returns the class name and reference address
        TesttoString t =  new TesttoString();
        System.out.println(t);
        System.out.println(t.toString());
    }
    
}
