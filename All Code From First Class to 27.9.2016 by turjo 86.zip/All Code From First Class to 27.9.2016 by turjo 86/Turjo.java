
public class Turjo {
    
    public static void main(String[] args){
        Programmer coder = new Programmer();
        coder.display();
    }
    
}
