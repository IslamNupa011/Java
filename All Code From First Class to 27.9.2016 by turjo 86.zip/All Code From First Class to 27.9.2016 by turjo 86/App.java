
import javax.swing.JFrame;


public class App 
{
    public static void main(String[] args)
    {
        JFrame frame = new JFrame("Hello World");
    }
    
    
}
