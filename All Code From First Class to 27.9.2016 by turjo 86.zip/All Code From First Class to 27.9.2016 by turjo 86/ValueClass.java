
import java.util.Scanner;


public class ValueClass 
{
    public static void main(String[] args)
    {
        String a;
        Scanner sc = new Scanner(System.in);
        System.out.println("Input A Value");
        a = sc.nextLine();
        System.out.println("Your Inputted Data " +  a);
    }
    
}
