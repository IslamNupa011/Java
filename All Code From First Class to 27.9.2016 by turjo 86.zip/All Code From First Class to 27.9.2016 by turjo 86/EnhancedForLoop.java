
public class EnhancedForLoop
{
    public static void main(String[] args)
    {
        int[] myArray = {45,52,56,85,47,86,75,89,88,62,69,78};
        System.out.println("The Array");
        for(int i : myArray)
        {
            System.out.print(i + " ");
        }
    }
    
}
